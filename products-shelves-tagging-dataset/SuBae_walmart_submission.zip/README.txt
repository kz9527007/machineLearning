1. Filename is hardcoded, so no need to specify it 
2. Run SuBae_walmart.py
